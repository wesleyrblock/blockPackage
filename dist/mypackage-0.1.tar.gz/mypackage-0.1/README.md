# blockPackage
This library was created as an example of how to publish your own Python Package

## building this package locally
'python setup.py sdist

## installing this package from Github
'pip install git+

## updating this package from GitHub
'pip install --upgrade git +